#ifndef BLINKY_H
#define BLINKY_H

int mainFunctionality(void);

#endif
